# e-commerce-website
Developing a demo e-commerce website with html, css, js, bootstrap and PHP.<br>
A demo Video - https://youtu.be/XVuRC8cfUno
<br>
The video mentioned above demonstrates the website developed in this repository.
The index.php file is in the signIn folder.<br>
